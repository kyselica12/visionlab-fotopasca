from tkinter import *
###
root = Tk()
root.title("Sys02")
#root.geometry("640x360")
root.resizable(0,0)
root.config(background="gray")
root.option_add("*Font", "courier 14")
###
resVar = StringVar(root)
resVar.set("1280x720") #default value
resolution = OptionMenu(root, resVar, "1280x720", "640x360", "320x180")
resolution.grid(row=0, columnspan=4, padx=(10,10), pady=(10,10))
###
framerate = Scale(root, from_=10, to=90, orient=HORIZONTAL, resolution=10)
framerate.grid(row=1, columnspan=4, padx=(10,10), pady=(10,10))
###
recVar = IntVar()
record = Checkbutton(root, text="nahrávanie", variable=recVar)
record.grid(row=2, column=0, padx=(10,10), pady=(10,10))
###
timelapseVar = IntVar()
timelapse = Checkbutton(root, text="časozber", variable=timelapseVar)
timelapse.grid(row=2, column=1, padx=(10,10), pady=(10,10))
###
alarmVar = IntVar()
alarm = Checkbutton(root, text="alarm", variable=alarmVar)
alarm.grid(row=2, column=2, padx=(10,10), pady=(10,10))
###
skipVar = IntVar()
skip = Checkbutton(root, text="preskoč", variable=skipVar)
skip.grid(row=2, column=3, padx=(10,10), pady=(10,10))
###
def zobraz():
    global resVar, fremerate, recVar, timelapseVar, alarmVar
    print("----------NASTAVENIA----------")
    print("rozlíšenie: " + str(resVar.get()))
    print("snímkovanie: " + str(framerate.get()))
    print("nahrávanie: " + str(recVar.get()))
    print("časozber: " + str(timelapseVar.get()))
    print("alarm: " + str(alarmVar.get()))
    print("preskoč konfiguráciu: " + str(skipVar.get()))
    print("------------------------------")
zobraz = Button(root,text="zobraz nastavenia",height=2,width=20,command=zobraz,bg="white")
zobraz.grid(row=3, column=0, columnspan=2, padx=(10,10), pady=(10,10))
###
uloz = Button(root,text="ulož nastavenia",height=2,width=20,command=lambda:print("Click..."),bg="white")
uloz.grid(row=3, column=2, columnspan=2, padx=(10,10), pady=(10,10))
###
root.mainloop()
