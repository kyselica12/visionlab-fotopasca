import numpy as np
import cv2
###
img = cv2.imread('img.jpg', cv2.IMREAD_COLOR)
cv2.namedWindow('Sys01')
height, width = img.shape[0], img.shape[1]
### ui elements
cv2.rectangle(img,(0, height-80),(width, height),(50,50,50),-1) #bar
cv2.rectangle(img,(575, 25),(800, 615),(0,255,0),3) #green rectangle
cv2.putText(img,'Timelapse is activated... Terminate the app with Q',(20,height-30), cv2.FONT_HERSHEY_SIMPLEX,1,(255,255,255),1,cv2.LINE_AA) #info text
### config button
UP_X = width - 150
UP_Y = height - 60
DOWN_X = width - 20
DOWN_Y = height - 20
cv2.rectangle(img,(UP_X, UP_Y),(DOWN_X , DOWN_Y),(0,0,0),-1)
cv2.rectangle(img,(UP_X, UP_Y),(DOWN_X , DOWN_Y),(255,255,255),2)
cv2.putText(img,'Config',(UP_X + 25,UP_Y + 27), cv2.FONT_HERSHEY_SIMPLEX,0.8,(255,255,255),1,cv2.LINE_AA)
### moouse event
def event(event,x,y,flags,param):
    if event == cv2.EVENT_MOUSEMOVE: #redraw button everytime
        if (x >= UP_X and y >= UP_Y and x <= DOWN_X and y <= DOWN_Y):
            cv2.rectangle(img,(UP_X, UP_Y),(DOWN_X , DOWN_Y),(255,255,255),-1)
            cv2.rectangle(img,(UP_X, UP_Y),(DOWN_X , DOWN_Y),(0,0,0),2)
            cv2.putText(img,'Config',(UP_X + 25,UP_Y + 27), cv2.FONT_HERSHEY_SIMPLEX,0.8,(0,0,0),1,cv2.LINE_AA)
        else:
            cv2.rectangle(img,(UP_X, UP_Y),(DOWN_X , DOWN_Y),(0,0,0),-1)
            cv2.rectangle(img,(UP_X, UP_Y),(DOWN_X , DOWN_Y),(255,255,255),2)
            cv2.putText(img,'Config',(UP_X + 25,UP_Y + 27), cv2.FONT_HERSHEY_SIMPLEX,0.8,(255,255,255),1,cv2.LINE_AA)
    elif event == cv2.EVENT_LBUTTONDOWN:
        if (x >= UP_X and y >= UP_Y and x <= DOWN_X and y <= DOWN_Y):
            print("Click...")       
cv2.setMouseCallback('Sys01',event)
###
while(True):
    cv2.imshow('Sys01',img)
    if cv2.waitKey(10) & 0xFF == ord('q'): #wait for 'q' to be pressed
        break
cv2.destroyAllWindows()


